import styled from 'styled-components'

export const FooterContainer = styled.div`
    display : flex;
    justify-content:center;
    align-items:center;
    color:black;
    background-color: rgba(94, 96, 171, 0.635);
`