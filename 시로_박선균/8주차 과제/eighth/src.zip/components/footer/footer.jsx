import React from 'react'
import {FooterContainer} from './footer.style'

const Footer = (()=>{
    return (
        <FooterContainer>
            <h1>상명대UMC화이팅!</h1>
        </FooterContainer>
    )
})
export default Footer